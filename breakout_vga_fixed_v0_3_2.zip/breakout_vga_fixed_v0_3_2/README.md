# Breakout VGA Fixed v0.3.2

This is the **testbench warning repair** for v0.3.1. The VGA / game RTL source files have not been changed.

Your Ubuntu v0.3.1 results confirm that `bash sim/lint_strict.sh` passes and all VGA headless smoke tests pass. `bash tb/run_tests.sh` then stopped on testbench-only `UNUSEDSIGNAL`/`BLKSEQ` warnings. Version 0.3.2 addresses those warnings at their source, without disabling Verilator's strict warning handling.

```bash
cd ~/桌面/breakout_vga_fixed_v0_3_2
bash sim/lint_strict.sh
bash sim/test_vga_headless.sh
bash tb/run_tests.sh
bash sim/run_simulation.sh
```

Four testbenches: game logic, VGA timing, key debounce and pixel renderer.

**Important:** This delivery was statically checked; Verilator 5.020 is not installed in the delivery environment. Whether all four testbenches pass must still be confirmed on Ubuntu. If there is another diagnostic, supply its first complete `%Warning`/`%Error` block.

---

# Breakout VGA Fixed v0.3.1 — key_debounce lint fix

This is a **one-line functional-equivalent patch** to v0.3, not a new game architecture.

- `rtl/key_debounce.v`: `COUNT_LAST` now performs subtraction on a deliberately sized parameter slice rather than implicitly truncating the 32-bit `integer` subtraction result. This targets `%Warning-WIDTHTRUNC` at `key_debounce.v:14` on Verilator 5.020.
- Scripts still use `-Wall` with fatal warnings; **no `-Wno-fatal`**.
- No other RTL/game logic is changed.

Ubuntu checks:

```bash
cd ~/桌面/breakout_vga_fixed_v0_3_1
bash sim/lint_strict.sh
bash sim/test_vga_headless.sh
bash tb/run_tests.sh
bash sim/run_simulation.sh
```

If `lint_strict.sh` fails with a **different** warning, please send the full output. This package has not been compiled with a real Verilator executable in the current generation environment.

---

# Breakout VGA 修复版 v0.3（LCD 暂缓）

这是 **Ubuntu VGA 640×480 游戏专用修复版**，在 v0.2 基础上修复坐标位宽、帧更新/按键缓存、加入实际驱动 HDL 的无图形显示器检查，以及像素渲染测试。**暂不修改 4.3 英寸 TFT-LCD 适配。**

> 状态：源码、脚本、C++ 语法及静态一致性可在制作环境检查，但制作环境没有 Verilator、Icarus 或 Quartus，因此 **未能在这里实际完成 HDL 编译 / GUI 运行**。用户 Ubuntu 上的 Verilator 5.020 必须按以下步骤验证。不能声称“零 Warning 已验证”。

## 安装与运行：Ubuntu 24.04 虚拟机

```bash
sudo apt update
sudo apt install -y build-essential verilator freeglut3-dev libglu1-mesa-dev libgl1-mesa-dev
cd ~/桌面/breakout_vga_fixed_v0_3 # 按实际解压路径修改
bash sim/lint_strict.sh
bash sim/test_vga_headless.sh
bash tb/run_tests.sh
bash sim/run_simulation.sh
```

以上所有脚本都使用 **严格 `-Wall`，不使用 `-Wno-fatal`**。

**如果你仅想打开窗口：**在项目根目录运行 `bash sim/run_simulation.sh`，无需传递 `../rtl` 路径。

### 键盘按键

| 键 | 功能 |
|---|---|
| A | 复位，回到开始页面并恢复全部 32 块砖 |
| S | 在开始页面进入游戏；游戏中按住向左移动 |
| D | 向右移动 |
| F | 朝右上方发射小球 |
| G | 朝左上方发射小球 |
| ESC | 退出 |

**注意：**须先 S 开始，再按 F 或 G 发射。请点击模拟器窗口使其获得键盘焦点。

## 新增“实际 HDL 冒烟测试” `sim/test_vga_headless.sh`

此测试让 Verilator 编译 **与可视化 GUI 相同的 `DevelopmentBoard` 和所有 Verilog**，仅将 `simulator.cpp` 换成不需要 OpenGL 的 `vga_smoke.cpp`。它会驱动完整的 800×525 VGA 扫描时钟并检查：

- 复位后 32 块砖和起始状态。
- 开始菜单红色边框、绿色背景。
- 640×480 每个有效像素都被扫到。
- S 开始游戏后 32 块砖、彩色砖行和挡板的 RGB565 颜色。
- F 发射后，下半场存在渲染成白色的小球。
- A 重置游戏状态和砖块状态。

这个测试不是“静态代码检查”，而是要求 **真实 Verilator 执行逻辑模拟**。本制作环境未安装 Verilator，因此测试能否通过需要你在 Ubuntu 运行确认。

## 文件说明

```text
rtl/               共用游戏 RTL，VGA 800×525 时序，逐帧逻辑，RGB565 渲染
sim/
  DevelopmentBoard.v   A/S/D/F/G 接口映射
  simulator.cpp        原风格的 800×600 VGA+LED 窗口
  vga_smoke.cpp        无图形界面 VGA 实测程序（新增）
  test_vga_headless.sh 运行上述测试（新增）
  lint_strict.sh       解析/检查模拟器及 VGA FPGA 两个顶层
  run_simulation.sh    编译并启动 GUI
quartus/           保留 v0.2 的 VGA Quartus 资料，未做新一轮实机测试
tb/                游戏、按键、VGA 帧时序、像素渲染四套 testbench
```

## 为什么不“直接屏蔽 Warning”

上一版 Ubuntu 日志中的 `WIDTHEXPAND` / `WIDTHTRUNC` 很多来自坐标与 integer 混用。现在游戏坐标预测统一使用 12-bit **signed**，像素比较使用明确扩宽的 **unsigned** 运算，动态砖块索引使用 5 位。任何 remaining Warning 都视为待修复，不自动忽略。

此外，游戏是逐帧更新状态的。物理按键消抖输出的瞬时脉冲只有一个系统时钟周期，如果不缓存到下一帧，容易发生偶然无效发射。所有发射/开始事件均缓存并在帧更新时消费。

## 目前明确的边界

- 该版本针对 Ubuntu Verilator VGA 模拟器，而不是 TFT-LCD，不要把 VGA 管脚直接接配套 LCD。
- 与原 Group 15 提交版功能对应，但不是逐像素复原课程原图。
- 不承诺 Quartus 上板、时序收敛或资源占用。使用 `quartus/` 前需实际跑 Quartus 并对照开发板手册核对引脚。
- 如果 `bash sim/lint_strict.sh` 出现 Warning，请提供 **整段诊断**。不要添加 `-Wno-fatal`，这样才能继续收敛警告为零。
- 如果冒烟测试失败，请粘贴 `FAIL: ...`；它能区分游戏状态错误、色彩编码、键盘事件和 VGA 扫描问题。

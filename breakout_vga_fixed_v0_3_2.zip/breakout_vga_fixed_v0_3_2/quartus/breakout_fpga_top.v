`timescale 1ns / 1ps
// Wildfire EP4CE10F17C8N board adapter. Same breakout_core as the simulator.
module breakout_fpga_top (
    input wire sys_clk,
    input wire sys_rst_n,
    input wire key_left_n,
    input wire key_right_n,
    input wire key_fire_right_n,
    input wire key_fire_left_n,
    output wire vga_hsync,
    output wire vga_vsync,
    output wire [15:0] vga_rgb
);
    // Debug/video observation pins are intentionally unconnected in hardware.
    /* verilator lint_off PINCONNECTEMPTY */
    breakout_core #(.DEBOUNCE_CYCLES(1000000)) core (
        .clk(sys_clk), .rst_n(sys_rst_n),
        .left_n(key_left_n), .right_n(key_right_n),
        .fire_right_n(key_fire_right_n), .fire_left_n(key_fire_left_n),
        .hsync(vga_hsync), .vsync(vga_vsync), .rgb(vga_rgb),
        .video_x(), .video_y(), .video_de(), .pixel_strobe(),
        .game_state(), .brick_debug()
    );
    /* verilator lint_on PINCONNECTEMPTY */
endmodule

#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
RTL=../rtl
verilator --version
verilator --cc --exe --build -j 2 -O2 -Wall \
  --top-module DevelopmentBoard \
  --Mdir obj_smoke \
  -CFLAGS '-std=c++17 -O2' \
  "$RTL/vga_timing.v" "$RTL/key_debounce.v" \
  "$RTL/game_logic.v" "$RTL/pixel_renderer.v" \
  "$RTL/breakout_core.v" DevelopmentBoard.v vga_smoke.cpp
./obj_smoke/VDevelopmentBoard

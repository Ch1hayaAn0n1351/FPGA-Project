`timescale 1ns / 1ps
// Legacy simulator-compatible port names and key mapping:
// A reset, S left/start, D right, F fire up-right, G fire up-left.
module DevelopmentBoard (
    input wire clk,
    input wire reset,
    input wire B2, B3, B4, B5,
    output wire h_sync, v_sync,
    output wire [15:0] rgb,
    output wire led1, led2, led3, led4, led5,
    // Additional observation ports for exact raster indexing in the new simulator.
    output wire [9:0] video_x, video_y,
    output wire video_de, pixel_strobe,
    output wire [1:0] game_state,
    output wire [31:0] brick_debug
);
    breakout_core #(.DEBOUNCE_CYCLES(8)) core (
        .clk(clk), .rst_n(reset),
        .left_n(B2), .right_n(B3),
        .fire_left_n(B5), .fire_right_n(B4),
        .hsync(h_sync), .vsync(v_sync), .rgb(rgb),
        .video_x(video_x), .video_y(video_y),
        .video_de(video_de), .pixel_strobe(pixel_strobe),
        .game_state(game_state), .brick_debug(brick_debug)
    );
    assign led1=~reset;
    assign led2=~B2;
    assign led3=~B3;
    assign led4=~B4;
    assign led5=~B5;
endmodule

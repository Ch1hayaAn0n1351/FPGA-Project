#!/usr/bin/env bash
# Verilator's default fatal-on-warning mode remains ON. Never use -Wno-fatal.
set -euo pipefail
cd "$(dirname "$0")"
verilator --version
RTL=../rtl
COMMON=("$RTL/vga_timing.v" "$RTL/key_debounce.v"         "$RTL/game_logic.v" "$RTL/pixel_renderer.v" "$RTL/breakout_core.v")
verilator --lint-only -Wall --top-module DevelopmentBoard     "${COMMON[@]}" DevelopmentBoard.v
verilator --lint-only -Wall --top-module breakout_fpga_top     "${COMMON[@]}" ../quartus/breakout_fpga_top.v
printf '\nPASS: strict lint completed for both top modules\n'

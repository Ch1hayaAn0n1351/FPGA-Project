// Headless functional smoke test of the exact RTL / simulation top used by GUI.
// Requires Verilator but does NOT need OpenGL or a DISPLAY server.
#include <verilated.h>
#include "VDevelopmentBoard.h"
#include <array>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <stdexcept>
#include <string>

static VDevelopmentBoard dut;
static std::array<uint16_t,640*480> framebuffer{};
static std::array<uint8_t,640*480> touched{};
static bool keys[5] = {false,false,false,false,false};
static uint64_t active_pixels = 0;

static void tick() {
    dut.clk=0;
    dut.reset=keys[0]?0:1;
    dut.B2=keys[1]?0:1;
    dut.B3=keys[2]?0:1;
    dut.B4=keys[3]?0:1;
    dut.B5=keys[4]?0:1;
    dut.eval();
    dut.clk=1;
    dut.eval();
    if (dut.pixel_strobe && dut.video_de) {
        const unsigned x=dut.video_x,y=dut.video_y;
        if (x>=640 || y>=480) throw std::runtime_error("VGA active pixel out of bounds");
        const size_t index=static_cast<size_t>(y)*640+x;
        framebuffer[index]=static_cast<uint16_t>(dut.rgb);
        touched[index]=1;
        ++active_pixels;
    }
    dut.clk=0;
    dut.eval();
}
static void ticks(uint64_t cycles) {
    for (uint64_t i=0;i<cycles;++i) tick();
}
static void expect(bool cond,const std::string &message) {
    if (!cond) throw std::runtime_error("FAIL: "+message);
    std::cout << "PASS: " << message << '\n';
}
static uint16_t pixel(unsigned x,unsigned y) {
    return framebuffer[static_cast<size_t>(y)*640+x];
}
static constexpr uint64_t FRAME_CLOCKS=2ULL*800*525;
int main(int argc,char **argv) {
    Verilated::commandArgs(argc,argv);
    try {
        keys[0]=true;
        ticks(5);
        expect(dut.game_state==0 && dut.brick_debug==0xFFFFFFFFu,"asynchronous reset and 32 bricks");
        keys[0]=false;
        touched.fill(0);
        ticks(FRAME_CLOCKS);
        expect(dut.game_state==0,"start screen still visible");
        expect(pixel(30,30)==0x0120,"start screen green background");
        expect(pixel(5,5)==0xF800,"start screen red border");
        unsigned visited=0;
        for (uint8_t value:touched) visited+=value;
        expect(visited==640u*480u,"all 640x480 active pixels visited");
        // Hold S just long enough to qualify as pressed, then run through frame boundary.
        keys[1]=true;
        ticks(FRAME_CLOCKS);
        keys[1]=false;
        ticks(FRAME_CLOCKS);
        expect(dut.game_state==1,"S entered PLAY screen");
        expect(dut.brick_debug==0xFFFFFFFFu,"32 bricks remain on game entry");
        expect(pixel(80,70)==0xF800,"top brick row visible and red");
        expect(pixel(80,96)==0x07E0,"second brick row visible and green");
        expect(pixel(320,454)==0xFFE0,"paddle visible and yellow");
        keys[3]=true; // F: launch right/up
        ticks(FRAME_CLOCKS);
        keys[3]=false;
        ticks(FRAME_CLOCKS);
        expect(dut.game_state==1,"game still active after F launches ball");
        // The ball is white once launched; seek it well below the brick field.
        bool has_white_ball=false;
        for(unsigned y=300;y<455;++y)
            for(unsigned x=120;x<520;++x)
                if(pixel(x,y)==0xFFFF) has_white_ball=true;
        expect(has_white_ball,"launched ball rendered in play field");
        keys[0]=true;
        ticks(4);
        expect(dut.game_state==0 && dut.brick_debug==0xFFFFFFFFu,
               "A reset returns menu and restores bricks");
        keys[0]=false;
        dut.final();
        std::cout << "ALL VGA RTL SMOKE TESTS PASSED\n";
        return 0;
    } catch(const std::exception &e) {
        std::cerr << e.what() << '\n';
        dut.final();
        return 1;
    }
}

`timescale 1ns / 1ps
// Same synthesized game/VGA RTL is used by BOTH Ubuntu and physical FPGA.
// Only DEBOUNCE_CYCLES differs for fast interactive software simulations.
module breakout_core #(
    parameter integer DEBOUNCE_CYCLES = 1000000
) (
    input  wire        clk,
    input  wire        rst_n,
    input  wire        left_n,
    input  wire        right_n,
    input  wire        fire_left_n,
    input  wire        fire_right_n,
    output wire        hsync,
    output wire        vsync,
    output wire [15:0] rgb,
    output wire [9:0]  video_x,
    output wire [9:0]  video_y,
    output wire        video_de,
    output wire        pixel_strobe,
    output wire [1:0]  game_state,
    output wire [31:0] brick_debug
);
    wire pixel_div, frame_tick_raw;
    wire frame_tick;
    wire [9:0] scan_h, scan_v;
    wire ld, rd, fld, frd;
    wire left_pulse, right_pulse, fl_pulse, fr_pulse;
    wire [9:0] px, bx, by;
    wire [31:0] bricks;
    wire [6:0] animation;
    wire launched;
    reg left_pending, fl_pending, fr_pending;

    vga_timing timing_inst (
        .clk(clk), .rst_n(rst_n), .pixel_div(pixel_div),
        .h_count(scan_h), .v_count(scan_v), .hsync(hsync), .vsync(vsync),
        .de(video_de), .pixel_x(video_x), .pixel_y(video_y),
        .frame_tick(frame_tick_raw)
    );
    // In the C++ simulator, sample VGA after rising edge when pixel_div=0.
    assign pixel_strobe = !pixel_div;
    // Check the raster terminal coordinate; these counters are NOT unused.
    assign frame_tick = frame_tick_raw &&
                        (scan_h == 10'd799) && (scan_v == 10'd524);
    assign brick_debug = bricks;

    key_debounce #(.STABLE_CYCLES(DEBOUNCE_CYCLES)) key_left (
        .clk(clk), .rst_n(rst_n), .key_n(left_n), .down(ld), .pressed(left_pulse));
    key_debounce #(.STABLE_CYCLES(DEBOUNCE_CYCLES)) key_right (
        .clk(clk), .rst_n(rst_n), .key_n(right_n), .down(rd), .pressed(right_pulse));
    key_debounce #(.STABLE_CYCLES(DEBOUNCE_CYCLES)) key_fire_left (
        .clk(clk), .rst_n(rst_n), .key_n(fire_left_n), .down(fld), .pressed(fl_pulse));
    key_debounce #(.STABLE_CYCLES(DEBOUNCE_CYCLES)) key_fire_right (
        .clk(clk), .rst_n(rst_n), .key_n(fire_right_n), .down(frd), .pressed(fr_pulse));

    // Key press pulses last ONE 50MHz clock, so retain them until frame_tick.
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            left_pending <= 1'b0;
            fl_pending <= 1'b0;
            fr_pending <= 1'b0;
        end else begin
            if (frame_tick) begin
                left_pending <= 1'b0;
                fl_pending <= 1'b0;
                fr_pending <= 1'b0;
            end else begin
                if (left_pulse) left_pending <= 1'b1;
                if (fl_pulse) fl_pending <= 1'b1;
                if (fr_pulse) fr_pending <= 1'b1;
            end
        end
    end

    game_logic game_inst (
        .clk(clk), .rst_n(rst_n), .frame_tick(frame_tick),
        .left_down(ld), .right_down(rd || right_pulse),
        .start_press(left_pending || left_pulse),
        .fire_left_press(fl_pending || (fl_pulse && fld)),
        .fire_right_press(fr_pending || (fr_pulse && frd)),
        .state(game_state), .launched(launched),
        .paddle_x(px), .ball_x(bx), .ball_y(by),
        .bricks(bricks), .animation(animation)
    );

    pixel_renderer render_inst (
        .de(video_de), .x(video_x), .y(video_y),
        .state(game_state), .launched(launched),
        .paddle_x(px), .ball_x(bx), .ball_y(by),
        .bricks(bricks), .animation(animation), .rgb(rgb)
    );
endmodule

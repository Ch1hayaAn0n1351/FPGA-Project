`timescale 1ns / 1ps
// One synchronous owner for every game register. VGA updates use frame_tick
// as a clock ENABLE; no generated clock or video-scan-derived collision flag.
module game_logic (
    input  wire        clk,
    input  wire        rst_n,
    input  wire        frame_tick,
    input  wire        left_down,
    input  wire        right_down,
    input  wire        start_press,
    input  wire        fire_left_press,
    input  wire        fire_right_press,
    output reg  [1:0]  state,
    output reg         launched,
    output reg  [9:0]  paddle_x,
    output reg  [9:0]  ball_x,
    output reg  [9:0]  ball_y,
    output reg  [31:0] bricks,
    output reg  [6:0]  animation
);
    localparam [1:0] ST_START = 2'd0, ST_PLAY = 2'd1,
                     ST_WIN   = 2'd2, ST_LOSE = 2'd3;
    localparam [9:0] PADDLE_MIN = 10'd92, PADDLE_MAX = 10'd548;
    localparam [9:0] PADDLE_INIT = 10'd320;
    localparam [9:0] BALL_INIT_Y = 10'd444;
    localparam [9:0] MOVE_STEP = 10'd8;
    localparam [9:0] BALL_LEFT = 10'd64, BALL_RIGHT = 10'd576;
    localparam [9:0] BALL_TOP = 10'd34, PADDLE_BOUNCE_Y = 10'd448;
    localparam signed [11:0] BALL_DELTA = 12'sd4;

    // Directions: 1 means left/up, 0 means right/down.
    reg dir_left, dir_up;

    wire [9:0] next_paddle =
        (left_down && !right_down) ?
            ((paddle_x > 10'd100) ? (paddle_x - MOVE_STEP) : PADDLE_MIN) :
        (right_down && !left_down) ?
            ((paddle_x < 10'd540) ? (paddle_x + MOVE_STEP) : PADDLE_MAX) :
            paddle_x;

    wire signed [11:0] current_x = $signed({2'b00,ball_x});
    wire signed [11:0] current_y = $signed({2'b00,ball_y});
    wire signed [11:0] next_px   = $signed({2'b00,next_paddle});
    wire signed [11:0] predicted_x = current_x +
                      (dir_left ? -BALL_DELTA : BALL_DELTA);
    wire signed [11:0] predicted_y = current_y +
                      (dir_up ? -BALL_DELTA : BALL_DELTA);

    wire hit_left = predicted_x <= 12'sd64;
    wire hit_right = predicted_x >= 12'sd576;
    wire hit_top = predicted_y <= 12'sd34;
    wire hit_paddle = !dir_up &&
        predicted_y + 12'sd4 >= 12'sd452 &&
        current_y + 12'sd4 < 12'sd452 &&
        predicted_x + 12'sd4 >= next_px - 12'sd32 &&
        predicted_x - 12'sd4 <= next_px + 12'sd32;
    wire hit_bottom = predicted_y + 12'sd4 >= 12'sd479;

    // Geometry-based hit test on predicted ball position (8x4 brick grid).
    reg brick_hit;
    reg [4:0] brick_hit_index;
    integer i;
    reg signed [11:0] brick_x, brick_y;
    always @(*) begin
        brick_hit = 1'b0;
        brick_hit_index = 5'd0;
        brick_x = 12'sd0;
        brick_y = 12'sd0;
        for (i = 0; i < 32; i = i + 1) begin
            brick_x = 12'sd70 + $signed({9'd0,i[2:0]}) * 12'sd64;
            brick_y = 12'sd64 + $signed({10'd0,i[4:3]}) * 12'sd26;
            if (!brick_hit && bricks[i] &&
                predicted_x + 12'sd4 >= brick_x &&
                predicted_x - 12'sd4 < brick_x + 12'sd60 &&
                predicted_y + 12'sd4 >= brick_y &&
                predicted_y - 12'sd4 < brick_y + 12'sd20) begin
                brick_hit = 1'b1;
                brick_hit_index = i[4:0];
            end
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= ST_START;
            launched <= 1'b0;
            paddle_x <= PADDLE_INIT;
            ball_x <= PADDLE_INIT;
            ball_y <= BALL_INIT_Y;
            bricks <= 32'hFFFFFFFF;
            dir_left <= 1'b0;
            dir_up <= 1'b1;
            animation <= 7'd0;
        end else if (frame_tick) begin
            animation <= animation + 7'd1;
            case (state)
                ST_START: begin
                    if (start_press || left_down) begin
                        state <= ST_PLAY;
                        launched <= 1'b0;
                        paddle_x <= PADDLE_INIT;
                        ball_x <= PADDLE_INIT;
                        ball_y <= BALL_INIT_Y;
                        bricks <= 32'hFFFFFFFF;
                    end
                end
                ST_PLAY: begin
                    paddle_x <= next_paddle;
                    if (!launched) begin
                        ball_x <= next_paddle;
                        ball_y <= BALL_INIT_Y;
                        if (fire_left_press || fire_right_press) begin
                            launched <= 1'b1;
                            dir_left <= fire_left_press;
                            dir_up <= 1'b1;
                        end
                    end else begin
                        if (hit_left) begin
                            ball_x <= BALL_LEFT;
                            dir_left <= 1'b0;
                        end else if (hit_right) begin
                            ball_x <= BALL_RIGHT;
                            dir_left <= 1'b1;
                        end else begin
                            // Safe here: out-of-range predictions are handled above.
                            ball_x <= predicted_x[9:0];
                        end

                        if (brick_hit) begin
                            bricks[brick_hit_index] <= 1'b0;
                            ball_y <= ball_y;
                            dir_up <= ~dir_up;
                            if ((bricks & ~(32'h1 << brick_hit_index)) == 32'h0)
                                state <= ST_WIN;
                        end else if (hit_paddle) begin
                            ball_y <= PADDLE_BOUNCE_Y;
                            dir_up <= 1'b1;
                            if (predicted_x < next_px - 12'sd8)
                                dir_left <= 1'b1;
                            else if (predicted_x > next_px + 12'sd8)
                                dir_left <= 1'b0;
                        end else if (hit_top) begin
                            ball_y <= BALL_TOP;
                            dir_up <= 1'b0;
                        end else if (hit_bottom) begin
                            state <= ST_LOSE;
                            ball_y <= 10'd475;
                        end else begin
                            ball_y <= predicted_y[9:0];
                        end
                    end
                end
                ST_WIN:  state <= ST_WIN;
                ST_LOSE: state <= ST_LOSE;
                default: state <= ST_START;
            endcase
        end
    end
endmodule

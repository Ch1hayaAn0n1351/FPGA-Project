`timescale 1ns / 1ps
// 640x480 RGB565 on-the-fly renderer; no framebuffer or external RAM.
module pixel_renderer (
    input wire de,
    input wire [9:0] x,
    input wire [9:0] y,
    input wire [1:0] state,
    input wire launched,
    input wire [9:0] paddle_x,
    input wire [9:0] ball_x,
    input wire [9:0] ball_y,
    input wire [31:0] bricks,
    input wire [6:0] animation,
    output reg [15:0] rgb
);
    localparam RGB_BLACK  = 16'h0000;
    localparam RGB_WHITE  = 16'hFFFF;
    localparam RGB_RED    = 16'hF800;
    localparam RGB_GREEN  = 16'h07E0;
    localparam RGB_BLUE   = 16'h001F;
    localparam RGB_YELLOW = 16'hFFE0;

    // 5x7 bitmap glyphs, bit 34=top left, bit 0=bottom right.
    function [34:0] glyph;
        input [7:0] letter;
        begin
            case (letter)
                "A": glyph = 35'b01110100011000111111100011000110001;
                "B": glyph = 35'b11110100011000111110100011000111110;
                "D": glyph = 35'b11110100011000110001100011000111110;
                "E": glyph = 35'b11111100001000011110100001000011111;
                "G": glyph = 35'b01111100001000010111100011000101110;
                "I": glyph = 35'b11111001000010000100001000010011111;
                "K": glyph = 35'b10001100101010011000101001001010001;
                "L": glyph = 35'b10000100001000010000100001000011111;
                "M": glyph = 35'b10001110111010110101100011000110001;
                "N": glyph = 35'b10001110011010110011100011000110001;
                "O": glyph = 35'b01110100011000110001100011000101110;
                "P": glyph = 35'b11110100011000111110100001000010000;
                "R": glyph = 35'b11110100011000111110101001001010001;
                "S": glyph = 35'b01111100001000001110000010000111110;
                "T": glyph = 35'b11111001000010000100001000010000100;
                "U": glyph = 35'b10001100011000110001100011000101110;
                "V": glyph = 35'b10001100011000110001100010101000100;
                "W": glyph = 35'b10001100011000110101101011010101010;
                "Y": glyph = 35'b10001100010101000100001000010000100;
                " ": glyph = 35'b00000000000000000000000000000000000;
                default: glyph = 35'b0;
            endcase
        end
    endfunction

    function [7:0] text_char;
        input [2:0] line_id;
        input [4:0] offset;
        begin
            text_char = " ";
            case (line_id)
                3'd0: begin
                    case(offset)
                        5'd0: text_char = "B";
                        5'd1: text_char = "R";
                        5'd2: text_char = "E";
                        5'd3: text_char = "A";
                        5'd4: text_char = "K";
                        5'd5: text_char = "O";
                        5'd6: text_char = "U";
                        5'd7: text_char = "T";
                        default: text_char = " ";
                    endcase
                end
                3'd1: begin
                    case(offset)
                        5'd0: text_char = "P";
                        5'd1: text_char = "R";
                        5'd2: text_char = "E";
                        5'd3: text_char = "S";
                        5'd4: text_char = "S";
                        5'd6: text_char = "S";
                        5'd8: text_char = "T";
                        5'd9: text_char = "O";
                        5'd11: text_char = "S";
                        5'd12: text_char = "T";
                        5'd13: text_char = "A";
                        5'd14: text_char = "R";
                        5'd15: text_char = "T";
                        default: text_char = " ";
                    endcase
                end
                3'd2: begin
                    case(offset)
                        5'd0: text_char = "Y";
                        5'd1: text_char = "O";
                        5'd2: text_char = "U";
                        5'd4: text_char = "W";
                        5'd5: text_char = "I";
                        5'd6: text_char = "N";
                        default: text_char = " ";
                    endcase
                end
                3'd3: begin
                    case(offset)
                        5'd0: text_char = "G";
                        5'd1: text_char = "A";
                        5'd2: text_char = "M";
                        5'd3: text_char = "E";
                        5'd5: text_char = "O";
                        5'd6: text_char = "V";
                        5'd7: text_char = "E";
                        5'd8: text_char = "R";
                        default: text_char = " ";
                    endcase
                end
                3'd4: begin
                    case(offset)
                        5'd0: text_char = "P";
                        5'd1: text_char = "R";
                        5'd2: text_char = "E";
                        5'd3: text_char = "S";
                        5'd4: text_char = "S";
                        5'd6: text_char = "A";
                        5'd8: text_char = "T";
                        5'd9: text_char = "O";
                        5'd11: text_char = "R";
                        5'd12: text_char = "E";
                        5'd13: text_char = "S";
                        5'd14: text_char = "E";
                        5'd15: text_char = "T";
                        default: text_char = " ";
                    endcase
                end
                default: text_char = " ";
            endcase
        end
    endfunction

    // Only scale=2 and scale=8 are used in this renderer. Shift instead
    // of inferring general combinational divider hardware for every glyph.
    function text_pixel;
        input [9:0] px, py, x0, y0;
        input [3:0] scale;
        input [2:0] line_id;
        input [4:0] length;
        integer index, col, row;
        reg [34:0] bits;
        reg [31:0] x_u, y_u, x_origin, y_origin, scale_u;
        reg [31:0] x_delta, y_delta;
        begin
            text_pixel = 1'b0;
            row = 0;
            col = 0;
            bits = 35'b0;
            x_u = {22'd0,px};
            y_u = {22'd0,py};
            x_origin = {22'd0,x0};
            y_origin = {22'd0,y0};
            scale_u = {28'd0,scale};
            x_delta = 32'd0;
            y_delta = 32'd0;
            if ((scale == 4'd2 || scale == 4'd8) &&
                y_u >= y_origin && y_u < y_origin + 32'd7 * scale_u) begin
                y_delta = y_u - y_origin;
                if (scale == 4'd8) row = y_delta >> 3;
                else row = y_delta >> 1;
                for (index=0; index<16; index=index+1) begin
                    if (index < {27'd0,length} &&
                        x_u >= x_origin + (index*6)*scale_u &&
                        x_u <  x_origin + (index*6+5)*scale_u) begin
                        x_delta = x_u - x_origin - (index*6)*scale_u;
                        if (scale == 4'd8) col = x_delta >> 3;
                        else col = x_delta >> 1;
                        bits = glyph(text_char(line_id,index[4:0]));
                        if (row >= 0 && row < 7 && col >= 0 && col < 5 &&
                            bits[(6-row)*5 + (4-col)])
                            text_pixel = 1'b1;
                    end
                end
            end
        end
    endfunction

    reg brick_pixel;
    reg [1:0] brick_row;
    integer idx;
    reg signed [11:0] brick_x, brick_y;
    wire signed [11:0] screen_x = $signed({2'b00,x});
    wire signed [11:0] screen_y = $signed({2'b00,y});
    always @(*) begin
        brick_pixel = 1'b0;
        brick_row = 2'd0;
        brick_x = 12'sd0;
        brick_y = 12'sd0;
        for (idx=0; idx<32; idx=idx+1) begin
            brick_x = 12'sd70 + $signed({9'd0,idx[2:0]}) * 12'sd64;
            brick_y = 12'sd64 + $signed({10'd0,idx[4:3]}) * 12'sd26;
            if (bricks[idx] &&
                screen_x >= brick_x && screen_x < brick_x + 12'sd60 &&
                screen_y >= brick_y && screen_y < brick_y + 12'sd20) begin
                brick_pixel = 1'b1;
                brick_row = idx[4:3];
            end
        end
    end

    // Widen both operands explicitly. The 10-bit coordinate must never be
    // compared to a 32-bit unsized arithmetic expression, nor underflow.
    wire [10:0] screen_x_w = {1'b0, x};
    wire [10:0] paddle_x_w = {1'b0, paddle_x};
    wire [10:0] ball_x_w = {1'b0, ball_x};
    wire [10:0] screen_y_w = {1'b0, y};
    wire [10:0] ball_y_w = {1'b0, ball_y};
    wire [10:0] win_bar_left = {4'd0, animation} << 2;

    always @(*) begin
        rgb = RGB_BLACK;
        if (de) begin
            case (state)
                2'd0: begin // start screen
                    rgb = 16'h0120; // deep green
                    if (x<10'd10 || x>=10'd630 || y<10'd10 || y>=10'd470) rgb = RGB_RED;
                    if (text_pixel(x,y,128,158,8,0,8) ||
                        text_pixel(x,y,224,278,2,1,16)) rgb = RGB_WHITE;
                end
                2'd1: begin // game screen
                    if ((x>=10'd60 && x<=10'd580 && y==10'd30) ||
                        (y>=10'd30 && x==10'd60) || (y>=10'd30 && x==10'd580)) rgb = RGB_WHITE;
                    if (brick_pixel) begin
                        case (brick_row)
                            2'd0: rgb=RGB_RED;
                            2'd1: rgb=RGB_GREEN;
                            2'd2: rgb=RGB_BLUE;
                            default: rgb=RGB_YELLOW;
                        endcase
                    end
                    if (screen_x_w >= paddle_x_w - 11'd32 &&
                        screen_x_w <  paddle_x_w + 11'd32 &&
                        y >= 10'd452 && y < 10'd458) rgb = RGB_YELLOW;
                    if (screen_x_w >= ball_x_w - 11'd4 &&
                        screen_x_w <  ball_x_w + 11'd4 &&
                        screen_y_w >= ball_y_w - 11'd4 &&
                        screen_y_w <  ball_y_w + 11'd4)
                        rgb = launched ? RGB_WHITE : RGB_GREEN;
                end
                2'd2: begin // win screen
                    rgb = 16'h0100;
                    if ((animation[4] && (x<10'd15 || x>=10'd625 ||
                                          y<10'd15 || y>=10'd465)) ||
                        (screen_x_w>=win_bar_left &&
                         screen_x_w<win_bar_left + 11'd48 &&
                         y>=10'd355 && y<10'd363))
                        rgb = RGB_RED;
                    if (text_pixel(x,y,152,180,8,2,7) ||
                        text_pixel(x,y,224,290,2,4,16)) rgb = RGB_WHITE;
                end
                default: begin // lost screen
                    rgb = (x[5]^y[5]) ? 16'h8410 : 16'h0088;
                    if (text_pixel(x,y,104,180,8,3,9) ||
                        text_pixel(x,y,224,290,2,4,16)) rgb = RGB_WHITE;
                end
            endcase
        end
    end
endmodule

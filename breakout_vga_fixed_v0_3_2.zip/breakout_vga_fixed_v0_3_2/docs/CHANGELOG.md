## v0.3.2 — Testbench strict lint repair (2026-10-08)

- `tb_game_logic.v`: use previously-unused ball position and animation outputs in actual assertions.
- `tb_game_logic.v`, `tb_key_debounce.v`, `tb_vga_timing.v`: use non-blocking assignments for testbench clock generation to address Verilator `BLKSEQ`.
- `tb_vga_timing.v`: verify exactly one frame tick over the 800x525 scan.
- `tb/run_tests.sh`: print per-test progress and final PASS. No `-Wno-fatal` flag is added.
- All game RTL and VGA simulator files remain unchanged from v0.3.1.
- Environment caveat: HDL toolchain unavailable here; run this on Ubuntu Verilator 5.020 before treating the tests as verified.

## v0.3.1 (2026-10-08)

- Corrected the sole `%Warning-WIDTHTRUNC` reported by Ubuntu Verilator 5.020 in `key_debounce.v` by explicitly matching subtractor operand/result widths.
- No feature changes or warning suppression; this is an isolated patch.
- Verilator recompilation is required on Ubuntu to confirm strict lint passes.

# v0.3 VGA-only (2026-10-08)

- Remains separate from 2025 Group 15 submission.
- Fixes paddle and ball renderer operand widths to 11-bit, explicit unsigned, without arithmetic wrap.
- Uses explicit 11-bit victory progress-band arithmetic.
- Makes key event latch clearing at frame boundary explicit; same-edge pulse still seen by game logic.
- Adds C++ Verilator `vga_smoke.cpp` test of the actual HDL top without OpenGL.
- Adds pixel renderer directed RGB565 tests and includes them in `tb/run_tests.sh`.
- Leaves `-Wall` warnings fatal: **NO `-Wno-fatal`** in scripts.
- TFT/LCD extension intentionally deferred; VGA top and Quartus settings are carried forward but unverified.

`timescale 1ns / 1ps
module tb_game_logic;
    reg clk=0, rst_n=1, frame_tick=0;
    reg left_down=0, right_down=0;
    reg start_press=0, fire_left_press=0, fire_right_press=0;
    wire [1:0] state;
    wire launched;
    wire [9:0] paddle_x, ball_x, ball_y;
    wire [31:0] bricks;
    wire [6:0] animation;
    always #10 clk<=~clk;
    game_logic dut(
        .clk(clk),.rst_n(rst_n),.frame_tick(frame_tick),
        .left_down(left_down),.right_down(right_down),
        .start_press(start_press),.fire_left_press(fire_left_press),
        .fire_right_press(fire_right_press),
        .state(state),.launched(launched),.paddle_x(paddle_x),
        .ball_x(ball_x),.ball_y(ball_y),.bricks(bricks),.animation(animation)
    );
    task frame;
        begin
            @(negedge clk);frame_tick=1;
            @(negedge clk);frame_tick=0;
            #1;
        end
    endtask
    task check;
        input test;
        input [8*80-1:0] label;
        begin
            if (!test) begin
                $display("FAIL: %0s",label);
                $finish(1);
            end
            $display("PASS: %0s",label);
        end
    endtask
    initial begin
        #1;rst_n=0;
        #5;check(state==0, "initial reset state");
        @(negedge clk);rst_n=1;
        start_press=1;frame();start_press=0;
        check(state==1,"start page -> game");
        check(bricks==32'hFFFFFFFF,"all 32 bricks present");
        check(ball_x==10'd320 && ball_y==10'd444,
              "initial ball follows paddle at (320,444)");
        check(animation==7'd1,"animation counter advances on frame tick");
        left_down=1;frame();left_down=0;
        check(paddle_x==10'd312,"left paddle move: 8 px/frame");
        check(ball_x==10'd312 && ball_y==10'd444,
              "unlaunched ball follows paddle left");
        right_down=1;frame();right_down=0;
        check(paddle_x==10'd320,"right paddle move: 8 px/frame");
        check(ball_x==10'd320 && ball_y==10'd444,
              "unlaunched ball follows paddle right");
        fire_right_press=1;frame();fire_right_press=0;
        check(launched==1,"fire key starts ball");
        check(dut.dir_left==0,"right-launch chooses rightward motion");
        @(negedge clk);dut.ball_x=10'd100;dut.ball_y=10'd89;
        dut.dir_left=0;dut.dir_up=1;
        frame();
        check(bricks[0]==0,"first brick hit and destroyed");
        // Last remaining brick hit must trigger victory.
        @(negedge clk);dut.bricks=32'h1;
        dut.ball_x=10'd100;dut.ball_y=10'd89;
        dut.dir_left=0;dut.dir_up=1;
        frame();
        check(state==2,"last brick -> WIN");
        @(negedge clk);rst_n=0;
        #1;check(state==0 && bricks==32'hFFFFFFFF,"reset restores game/brick state");
        @(negedge clk);rst_n=1;
        start_press=1;frame();start_press=0;
        fire_left_press=1;frame();fire_left_press=0;
        check(launched==1 && dut.dir_left==1,"left-launch chooses leftward motion");
        @(negedge clk);dut.ball_x=10'd400;dut.ball_y=10'd473;
        dut.dir_left=1;dut.dir_up=0;
        frame();
        check(state==3,"missed paddle -> LOSE");
        $display("ALL GAME LOGIC TESTS PASSED");
        $finish;
    end
endmodule

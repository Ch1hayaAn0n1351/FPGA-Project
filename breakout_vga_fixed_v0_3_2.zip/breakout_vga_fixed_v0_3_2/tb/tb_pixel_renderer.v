`timescale 1ns/1ps
// Combinational RGB565 rendering contract: no VGA clock required here.
module tb_pixel_renderer;
    reg de = 1'b1;
    reg [9:0] x = 10'd30, y = 10'd30;
    reg [1:0] state = 2'd0;
    reg launched = 1'b0;
    reg [9:0] paddle_x = 10'd320, ball_x = 10'd320, ball_y = 10'd444;
    reg [31:0] bricks = 32'hFFFFFFFF;
    reg [6:0] animation = 7'd0;
    wire [15:0] rgb;
    pixel_renderer dut(.de(de),.x(x),.y(y),.state(state),.launched(launched),
        .paddle_x(paddle_x),.ball_x(ball_x),.ball_y(ball_y),
        .bricks(bricks),.animation(animation),.rgb(rgb));
    task expect_rgb;
        input [15:0] expected;
        input [8*80-1:0] message;
        begin
            #1;
            if(rgb !== expected) begin
                $display("FAIL %0s: got %h expected %h",message,rgb,expected);
                $fatal(1);
            end
            $display("PASS %0s",message);
        end
    endtask
    initial begin
        expect_rgb(16'h0120,"menu background");
        x=10'd5;y=10'd5; expect_rgb(16'hF800,"menu red border");
        de=0;expect_rgb(16'h0000,"VGA blanking output black");
        de=1;state=2'd1;x=10'd80;y=10'd70;
        expect_rgb(16'hF800,"brick row 0 red");
        y=10'd96; expect_rgb(16'h07E0,"brick row 1 green");
        y=10'd122; expect_rgb(16'h001F,"brick row 2 blue");
        y=10'd148; expect_rgb(16'hFFE0,"brick row 3 yellow");
        bricks[0]=0; x=10'd80;y=10'd70;
        expect_rgb(16'h0000,"destroyed brick invisible");
        x=10'd320;y=10'd454;expect_rgb(16'hFFE0,"paddle yellow");
        y=10'd444; expect_rgb(16'h07E0,"unlaunched ball green");
        launched=1; expect_rgb(16'hFFFF,"launched ball white");
        state=2'd3;x=10'd40;y=10'd30;
        expect_rgb(16'h8410,"loss checkerboard");
        $display("ALL PIXEL RENDERER TESTS PASSED");
        $finish;
    end
endmodule

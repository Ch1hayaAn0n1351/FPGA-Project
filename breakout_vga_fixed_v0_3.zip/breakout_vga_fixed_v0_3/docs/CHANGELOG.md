# v0.3 VGA-only (2026-10-08)

- Remains separate from 2025 Group 15 submission.
- Fixes paddle and ball renderer operand widths to 11-bit, explicit unsigned, without arithmetic wrap.
- Uses explicit 11-bit victory progress-band arithmetic.
- Makes key event latch clearing at frame boundary explicit; same-edge pulse still seen by game logic.
- Adds C++ Verilator `vga_smoke.cpp` test of the actual HDL top without OpenGL.
- Adds pixel renderer directed RGB565 tests and includes them in `tb/run_tests.sh`.
- Leaves `-Wall` warnings fatal: **NO `-Wno-fatal`** in scripts.
- TFT/LCD extension intentionally deferred; VGA top and Quartus settings are carried forward but unverified.

`timescale 1ns / 1ps
// 640x480 RGB565 on-the-fly renderer; no framebuffer or external RAM.
module pixel_renderer (
    input wire de,
    input wire [9:0] x,
    input wire [9:0] y,
    input wire [1:0] state,
    input wire launched,
    input wire [9:0] paddle_x,
    input wire [9:0] ball_x,
    input wire [9:0] ball_y,
    input wire [31:0] bricks,
    input wire [6:0] animation,
    output reg [15:0] rgb
);
    localparam RGB_BLACK  = 16'h0000;
    localparam RGB_WHITE  = 16'hFFFF;
    localparam RGB_RED    = 16'hF800;
    localparam RGB_GREEN  = 16'h07E0;
    localparam RGB_BLUE   = 16'h001F;
    localparam RGB_YELLOW = 16'hFFE0;

    // 5x7 bitmap glyphs, bit 34=top left, bit 0=bottom right.
    function [34:0] glyph;
        input [7:0] letter;
        begin
            case (letter)
                "A": glyph = 35'b01110100011000111111100011000110001;
                "B": glyph = 35'b11110100011000111110100011000111110;
                "D": glyph = 35'b11110100011000110001100011000111110;
                "E": glyph = 35'b11111100001000011110100001000011111;
                "G": glyph = 35'b01111100001000010111100011000101110;
                "I": glyph = 35'b11111001000010000100001000010011111;
                "K": glyph = 35'b10001100101010011000101001001010001;
                "L": glyph = 35'b10000100001000010000100001000011111;
                "M": glyph = 35'b10001110111010110101100011000110001;
                "N": glyph = 35'b10001110011010110011100011000110001;
                "O": glyph = 35'b01110100011000110001100011000101110;
                "P": glyph = 35'b11110100011000111110100001000010000;
                "R": glyph = 35'b11110100011000111110101001001010001;
                "S": glyph = 35'b01111100001000001110000010000111110;
                "T": glyph = 35'b11111001000010000100001000010000100;
                "U": glyph = 35'b10001100011000110001100011000101110;
                "V": glyph = 35'b10001100011000110001100010101000100;
                "W": glyph = 35'b10001100011000110101101011010101010;
                "Y": glyph = 35'b10001100010101000100001000010000100;
                " ": glyph = 35'b00000000000000000000000000000000000;
                default: glyph = 35'b0;
            endcase
        end
    endfunction

    function [7:0] text_char;
        input [2:0] line_id;
        input [4:0] offset;
        begin
            text_char = " ";
            case (line_id)
                3'd0: begin
                    case(offset)
                        5'd0: text_char = "B";
                        5'd1: text_char = "R";
                        5'd2: text_char = "E";
                        5'd3: text_char = "A";
                        5'd4: text_char = "K";
                        5'd5: text_char = "O";
                        5'd6: text_char = "U";
                        5'd7: text_char = "T";
                    endcase
                end
                3'd1: begin
                    case(offset)
                        5'd0: text_char = "P";
                        5'd1: text_char = "R";
                        5'd2: text_char = "E";
                        5'd3: text_char = "S";
                        5'd4: text_char = "S";
                        5'd6: text_char = "S";
                        5'd8: text_char = "T";
                        5'd9: text_char = "O";
                        5'd11: text_char = "S";
                        5'd12: text_char = "T";
                        5'd13: text_char = "A";
                        5'd14: text_char = "R";
                        5'd15: text_char = "T";
                    endcase
                end
                3'd2: begin
                    case(offset)
                        5'd0: text_char = "Y";
                        5'd1: text_char = "O";
                        5'd2: text_char = "U";
                        5'd4: text_char = "W";
                        5'd5: text_char = "I";
                        5'd6: text_char = "N";
                    endcase
                end
                3'd3: begin
                    case(offset)
                        5'd0: text_char = "G";
                        5'd1: text_char = "A";
                        5'd2: text_char = "M";
                        5'd3: text_char = "E";
                        5'd5: text_char = "O";
                        5'd6: text_char = "V";
                        5'd7: text_char = "E";
                        5'd8: text_char = "R";
                    endcase
                end
                3'd4: begin
                    case(offset)
                        5'd0: text_char = "P";
                        5'd1: text_char = "R";
                        5'd2: text_char = "E";
                        5'd3: text_char = "S";
                        5'd4: text_char = "S";
                        5'd6: text_char = "A";
                        5'd8: text_char = "T";
                        5'd9: text_char = "O";
                        5'd11: text_char = "R";
                        5'd12: text_char = "E";
                        5'd13: text_char = "S";
                        5'd14: text_char = "E";
                        5'd15: text_char = "T";
                    endcase
                end
            endcase
        end
    endfunction

    function text_pixel;
        input [9:0] px, py, x0, y0;
        input [3:0] scale;
        input [2:0] line_id;
        input [4:0] length;
        integer index, col, row;
        reg [34:0] bits;
        begin
            text_pixel = 1'b0;
            row = 0;
            col = 0;
            bits = 35'b0;
            if (py >= y0 && py < y0 + 7*scale) begin
                row = (py-y0)/scale;
                for (index=0; index<16; index=index+1) begin
                    if (index < length &&
                        px >= x0 + index*6*scale &&
                        px <  x0 + (index*6+5)*scale) begin
                        col = (px - x0 - index*6*scale)/scale;
                        bits = glyph(text_char(line_id,index));
                        if (bits[(6-row)*5 + (4-col)])
                            text_pixel = 1'b1;
                    end
                end
            end
        end
    endfunction

    reg brick_pixel;
    reg [1:0] brick_row;
    integer idx;
    integer bx, by;
    always @(*) begin
        brick_pixel = 1'b0;
        brick_row = 2'b00;
        bx = 0;
        by = 0;
        for (idx=0; idx<32; idx=idx+1) begin
            bx = 70 + (idx%8)*64;
            by = 64 + (idx/8)*26;
            if (bricks[idx] && x>=bx && x<bx+60 && y>=by && y<by+20) begin
                brick_pixel = 1'b1;
                brick_row = idx/8;
            end
        end
    end

    always @(*) begin
        rgb = RGB_BLACK;
        if (de) begin
            case (state)
                2'd0: begin // start screen
                    rgb = 16'h0120; // deep green
                    if (x<10 || x>=630 || y<10 || y>=470) rgb = RGB_RED;
                    if (text_pixel(x,y,128,158,8,0,8) ||
                        text_pixel(x,y,224,278,2,1,16)) rgb = RGB_WHITE;
                end
                2'd1: begin // game screen
                    if ((x>=60 && x<=580 && y==30) ||
                        (y>=30 && x==60) || (y>=30 && x==580)) rgb = RGB_WHITE;
                    if (brick_pixel) begin
                        case (brick_row)
                            2'd0: rgb=RGB_RED;
                            2'd1: rgb=RGB_GREEN;
                            2'd2: rgb=RGB_BLUE;
                            default: rgb=RGB_YELLOW;
                        endcase
                    end
                    if (x>=paddle_x-32 && x<paddle_x+32 &&
                        y>=452 && y<458) rgb = RGB_YELLOW;
                    if (x>=ball_x-4 && x<ball_x+4 &&
                        y>=ball_y-4 && y<ball_y+4) rgb=RGB_WHITE;
                end
                2'd2: begin // win screen
                    rgb = 16'h0100;
                    if ((animation[4] && (x<15 || x>=625 || y<15 || y>=465)) ||
                        (x>=({3'b000,animation}<<2) &&
                         x<({3'b000,animation}<<2)+48 && y>=355 && y<363))
                        rgb = RGB_RED;
                    if (text_pixel(x,y,152,180,8,2,7) ||
                        text_pixel(x,y,224,290,2,4,16)) rgb = RGB_WHITE;
                end
                default: begin // lost screen
                    rgb = (x[5]^y[5]) ? 16'h8410 : 16'h0088;
                    if (text_pixel(x,y,104,180,8,3,9) ||
                        text_pixel(x,y,224,290,2,4,16)) rgb = RGB_WHITE;
                end
            endcase
        end
    end
endmodule

`timescale 1ns / 1ps
// Breakout state has ONE sequential owner (this module, at clk=50 MHz).
// Visible playing field x=60..580, y=30..479. 8 columns x 4 rows.
module game_logic (
    input  wire        clk,
    input  wire        rst_n,
    input  wire        frame_tick,
    input  wire        left_down,
    input  wire        right_down,
    input  wire        start_press,
    input  wire        fire_left_press,
    input  wire        fire_right_press,
    output reg  [1:0]  state,
    output reg         launched,
    output reg  [9:0]  paddle_x,
    output reg  [9:0]  ball_x,
    output reg  [9:0]  ball_y,
    output reg  [31:0] bricks,
    output reg  [6:0]  animation
);
    localparam ST_START = 2'd0;
    localparam ST_PLAY  = 2'd1;
    localparam ST_WIN   = 2'd2;
    localparam ST_LOSE  = 2'd3;

    localparam integer LEFT = 60, RIGHT = 580, TOP = 30;
    localparam integer PADDLE_Y = 455, PADDLE_HALF_W = 32, PADDLE_TOP = 452;
    localparam integer BALL_HALF = 4;
    localparam integer MOVE_STEP = 8, BALL_STEP = 4;

    // Direction encoding: 1=left/up, 0=right/down.
    reg dir_left, dir_up;
    wire [9:0] next_paddle = left_down && !right_down
         ? ((paddle_x > LEFT + PADDLE_HALF_W + MOVE_STEP) ? paddle_x - MOVE_STEP : LEFT + PADDLE_HALF_W)
         : right_down && !left_down
         ? ((paddle_x < RIGHT - PADDLE_HALF_W - MOVE_STEP) ? paddle_x + MOVE_STEP : RIGHT - PADDLE_HALF_W)
         : paddle_x;

    wire signed [11:0] predicted_x = $signed({2'b00, ball_x}) +
             (dir_left ? -12'sd4 : 12'sd4);
    wire signed [11:0] predicted_y = $signed({2'b00, ball_y}) +
             (dir_up ? -12'sd4 : 12'sd4);

    wire hit_left = predicted_x <= LEFT + BALL_HALF;
    wire hit_right = predicted_x >= RIGHT - BALL_HALF;
    wire hit_top = predicted_y <= TOP + BALL_HALF;
    wire hit_paddle = !dir_up &&
            predicted_y + BALL_HALF >= PADDLE_TOP &&
            ball_y + BALL_HALF < PADDLE_TOP &&
            predicted_x + BALL_HALF >= $signed({2'b00,next_paddle}) - PADDLE_HALF_W &&
            predicted_x - BALL_HALF <= $signed({2'b00,next_paddle}) + PADDLE_HALF_W;
    wire hit_bottom = predicted_y + BALL_HALF >= 479;

    // Check geometry at the ball's predicted next frame position, rather than
    // using pixels already drawn by the VGA raster scanner.
    reg brick_hit;
    reg [4:0] brick_hit_index;
    integer i;
    integer bx, by;
    always @(*) begin
        brick_hit = 1'b0;
        brick_hit_index = 5'd0;
        bx = 0;
        by = 0;
        for (i = 0; i < 32; i = i + 1) begin
            bx = 70 + (i % 8) * 64;
            by = 64 + (i / 8) * 26;
            if (!brick_hit && bricks[i] &&
                predicted_x + BALL_HALF >= bx &&
                predicted_x - BALL_HALF < bx + 60 &&
                predicted_y + BALL_HALF >= by &&
                predicted_y - BALL_HALF < by + 20) begin
                brick_hit = 1'b1;
                brick_hit_index = i;
            end
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= ST_START;
            launched <= 1'b0;
            paddle_x <= 10'd320;
            ball_x <= 10'd320;
            ball_y <= 10'd444;
            bricks <= 32'hFFFFFFFF;
            dir_left <= 1'b0;
            dir_up <= 1'b1;
            animation <= 7'd0;
        end else begin
            if (frame_tick) begin
                animation <= animation + 7'd1;
                case (state)
                    ST_START: begin
                        if (start_press || left_down) begin
                            state <= ST_PLAY;
                            launched <= 1'b0;
                            paddle_x <= 10'd320;
                            ball_x <= 10'd320;
                            ball_y <= 10'd444;
                            bricks <= 32'hFFFFFFFF;
                        end
                    end
                    ST_PLAY: begin
                        paddle_x <= next_paddle;
                        if (!launched) begin
                            ball_x <= next_paddle;
                            ball_y <= 10'd444;
                            if (fire_left_press || fire_right_press) begin
                                launched <= 1'b1;
                                dir_left <= fire_left_press;
                                dir_up <= 1'b1;
                            end
                        end else begin
                            if (hit_left) begin
                                ball_x <= LEFT + BALL_HALF;
                                dir_left <= 1'b0;
                            end else if (hit_right) begin
                                ball_x <= RIGHT - BALL_HALF;
                                dir_left <= 1'b1;
                            end else begin
                                ball_x <= predicted_x[9:0];
                            end

                            if (brick_hit) begin
                                bricks[brick_hit_index] <= 1'b0;
                                ball_y <= ball_y; // separate from hit object before the next frame
                                dir_up <= ~dir_up;
                                if ((bricks & ~(32'h1 << brick_hit_index)) == 0)
                                    state <= ST_WIN;
                            end else if (hit_paddle) begin
                                ball_y <= PADDLE_TOP - BALL_HALF;
                                dir_up <= 1'b1;
                                // Paddle hit location biases horizontal direction.
                                if (predicted_x < $signed({2'b00,next_paddle}) - 8)
                                    dir_left <= 1'b1;
                                else if (predicted_x > $signed({2'b00,next_paddle}) + 8)
                                    dir_left <= 1'b0;
                            end else if (hit_top) begin
                                ball_y <= TOP + BALL_HALF;
                                dir_up <= 1'b0;
                            end else if (hit_bottom) begin
                                state <= ST_LOSE;
                                ball_y <= 10'd475;
                            end else begin
                                ball_y <= predicted_y[9:0];
                            end
                        end
                    end
                    ST_WIN:  state <= ST_WIN;
                    ST_LOSE: state <= ST_LOSE;
                    default: state <= ST_START;
                endcase
            end
        end
    end
endmodule

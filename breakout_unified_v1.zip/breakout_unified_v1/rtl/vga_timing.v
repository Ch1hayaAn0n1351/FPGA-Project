`timescale 1ns / 1ps
// 50 MHz single-clock VGA 640x480 @ ~59.52 Hz (25 MHz pixel enable).
// Horizontal: 96 sync + 48 back + 640 active + 16 front = 800.
// Vertical:    2 sync + 33 back + 480 active + 10 front = 525.
module vga_timing (
    input  wire        clk,
    input  wire        rst_n,
    output reg         pixel_div,
    output reg [9:0]   h_count,
    output reg [9:0]   v_count,
    output wire        hsync,
    output wire        vsync,
    output wire        de,
    output wire [9:0]  pixel_x,
    output wire [9:0]  pixel_y,
    output wire        frame_tick
);
    localparam H_TOTAL = 800;
    localparam V_TOTAL = 525;
    localparam H_ACTIVE_BEGIN = 96 + 48;
    localparam V_ACTIVE_BEGIN = 2 + 33;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            pixel_div <= 1'b0;
            h_count <= 10'd0;
            v_count <= 10'd0;
        end else begin
            pixel_div <= ~pixel_div;
            if (pixel_div) begin
                if (h_count == H_TOTAL - 1) begin
                    h_count <= 10'd0;
                    if (v_count == V_TOTAL - 1)
                        v_count <= 10'd0;
                    else
                        v_count <= v_count + 10'd1;
                end else begin
                    h_count <= h_count + 10'd1;
                end
            end
        end
    end

    assign hsync = (h_count >= 96);
    assign vsync = (v_count >= 2);
    assign de = (h_count >= H_ACTIVE_BEGIN) &&
                (h_count < H_ACTIVE_BEGIN + 640) &&
                (v_count >= V_ACTIVE_BEGIN) &&
                (v_count < V_ACTIVE_BEGIN + 480);
    assign pixel_x = de ? h_count - H_ACTIVE_BEGIN : 10'd0;
    assign pixel_y = de ? v_count - V_ACTIVE_BEGIN : 10'd0;
    assign frame_tick = pixel_div && (h_count == H_TOTAL - 1) &&
                        (v_count == V_TOTAL - 1);
endmodule

`timescale 1ns / 1ps
// Active-low input. Outputs a held pressed level and one 50 MHz press pulse.
// STABLE_CYCLES=1_000_000 => 20ms at 50 MHz. Simulator can override to 4.
module key_debounce #(
    parameter integer STABLE_CYCLES = 1000000,
    parameter integer COUNTER_BITS = (STABLE_CYCLES <= 1) ? 1 : $clog2(STABLE_CYCLES)
) (
    input  wire clk,
    input  wire rst_n,
    input  wire key_n,
    output wire down,
    output reg  pressed
);
    reg sync_a, sync_b, stable_n;
    reg [COUNTER_BITS-1:0] stable_count;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            sync_a <= 1'b1;
            sync_b <= 1'b1;
            stable_n <= 1'b1;
            stable_count <= {COUNTER_BITS{1'b0}};
            pressed <= 1'b0;
        end else begin
            sync_a <= key_n;
            sync_b <= sync_a;
            pressed <= 1'b0;
            if (sync_b == stable_n) begin
                stable_count <= {COUNTER_BITS{1'b0}};
            end else if (stable_count == STABLE_CYCLES - 1) begin
                stable_n <= sync_b;
                stable_count <= {COUNTER_BITS{1'b0}};
                if (!sync_b)
                    pressed <= 1'b1;
            end else begin
                stable_count <= stable_count + 1'b1;
            end
        end
    end
    assign down = !stable_n;
endmodule

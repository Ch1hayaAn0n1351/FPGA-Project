# FPGA Breakout — Unified Simulator / Wildfire Zhengtu Pro v0.1

**Status: first source release. HDL compile and board operation are NOT yet independently verified.**

This is a new implementation informed by the Group 15 EIE330 2025 submission, `BreakoutGame` at GitHub commit `e4628adeaa9f`, the older `48bb798` source, and the user's `fpga_breakout.zip` hardware prototype. It is not a byte-for-byte patch and it **does not overwrite** the course submission.

The **exact same** `rtl/breakout_core.v` and all its RTL dependencies are used in both environments. Only top-level inputs and keyboard debounce duration differ.

## Features

- VGA 640×480 visible pixels, 800×525 total timing, 25 MHz effective pixel rate from 50 MHz system clock; ~59.52 Hz.
- RGB565 output, inactive video blanked to black.
- 8 columns × 4 rows = 32 bricks; four brick colors.
- Start/menu screen, paddles + ball, geometry-based brick/paddle/wall collision, win/loss screens.
- Left/right paddle control and separate up-right/up-left ball launches.
- Reset restores all bricks, ball/paddle and start screen.
- On physical hardware: 2-flop input synchronizers and 20ms debounce; in GUI simulator debounce shortened for usability.
- No separate fabric-derived clock domain, no raster-based collision decisions, no procedural multi-writer for `bricks`, no self-feedback continuous assignments.

## Ubuntu 22.04/24.04: Simulator (desktop GUI)

```bash
sudo apt update
sudo apt install -y build-essential verilator freeglut3-dev libglu1-mesa-dev libgl1-mesa-dev
cd breakout_unified_v1
bash sim/run_simulation.sh
```

Requires a working graphical desktop / WSLg. The first Verilator compilation may take some time. `run_simulation.sh` creates **`sim/obj_dir`** and starts a new 800×600 VGA+LED virtual board window. The simulation steps are logically cycle-accurate but may run slower than a physical 60 Hz display; computer performance determines speed.

### Keyboard

| Key | Purpose |
| --- | --- |
| `A` | Hold to reset; release to return to start screen |
| `S` | On menu: start. In game: hold for paddle left |
| `D` | Hold for paddle right |
| `F` | Launch ball **up-right** |
| `G` | Launch ball **up-left** |
| `Esc` | Close simulator |

Click the simulator window before typing. In the game, first press **S** to leave the menu, then **F** or **G** to launch. A held S during the initial game frame can also move the paddle left.

## Automated RTL tests

```bash
bash tb/run_tests.sh
```

Tries `iverilog` first, or Verilator 5+ if available. Checks start, fire, brick collision, victory, loss, reset, and VGA raster timing. This is a useful first gate, **not** a replacement for actual GUI, Quartus Timing Analyzer, or board testing.

If an installed Verilator rejects or warns about a Verilog construct, share the exact error log instead of assuming synthesis passed. These scripts have been packaged for Ubuntu; our authoring environment does not have HDL tools installed.

## Quartus / Wildfire Zhengtu Pro

1. Open `quartus/breakout.qpf` in Intel Quartus Prime **Lite** supporting Cyclone IV E.
2. Check the board is **EP4CE10F17C8N**, the four active-low keys are connected, and the 16-bit RGB565 VGA DAC pin assignments match the official manual.
3. Set `breakout_fpga_top` as the top-level entity (already specified in QSF), then **Analysis & Synthesis**, full compilation, and review **Timing Analyzer** reports.
4. Check pin voltage/drive electrical compatibility and output timing. Only if full compile and board pin verification pass, use **Programmer** with USB-Blaster to download the generated `.sof`.
5. Hardware keys: **KEY1** start/left, **KEY2** right, **KEY3** launch right, **KEY4** launch left. **RESET** returns to the menu.

Unlike the 2025 course report, this source is intended for a physical Cyclone IV E board, **but it has not been synthesized and programmed on a board yet**. Actual fit (LE resources), timing closure, and screen behavior remain to be tested. Output sync uses conventional active-low H/V; the official Wildfire example drives active-high H/V pulses. If your monitor rejects the mode, verify required sync polarity and adjust both timing module outputs consistently for simulator and hardware.

Official board reference:
- https://doc.embedfire.com/fpga/altera/ep4ce10_pro/zh/latest/code/vga.html
- https://doc.embedfire.com/fpga/altera/ep4ce10_pro/zh/latest/code/vga_char.html
- https://doc.embedfire.com/fpga/altera/ep4ce10_pro/zh/latest/code/dds.html

## Files

```text
rtl/
  vga_timing.v       50 MHz clock, 25 MHz VGA enables, 800×525 raster, frame tick
  key_debounce.v     Async mechanical key input synchronization and debounce
  game_logic.v       Sole owner of ball, paddle, brick, game-state registers
  pixel_renderer.v   16-bit RGB565 geometry, start/menu/victory/failure screens
  breakout_core.v   Hardware-independent integration and key-event latch
sim/
  DevelopmentBoard.v   Original-style A/S/D/F/G keyboard adapter
  simulator.cpp       New single-threaded GLUT VGA+LED window
  run_simulation.sh    Build and run with Verilator
quartus/
  breakout_fpga_top.v  Wildfire board-specific top adapter
  breakout.qpf/.qsf    Cyclone IV E project and official pin assignments
  breakout.sdc         50 MHz clock timing constraint
tb/
  tb_game_logic.v      Directed game-state tests
  tb_vga_timing.v      800×525 timings tests
  run_tests.sh         Runs on Icarus or Verilator
```

## Limitations / next validation

- Software C++ GUI and Verilog simulation have **not been compiled in this authoring container** because the required Verilator/GLUT and HDL simulation packages are not installed there.
- No Quartus synthesis/fit, timing closure, or `.sof` has been produced from this version.
- Character graphics use a combinational 5×7 font; whether this fits comfortably in EP4CE10 should be checked in Quartus. If not, replace with a small synchronous ROM while retaining the game core.
- This version intentionally leaves out the incomplete `Transmit/116` scoring prototype to focus on a working original-game feature set.
- The color scheme/menus correspond functionally to the 2025 course report but are a fresh implementation, **not** pixel-identical screenshots of the submission.
- Game logic updates at the 60Hz frame boundary; use further tests for brick side-impact and multi-brick corner edge cases.

## GitHub organization

Place this directory at the repository root as `breakout_fpga/` on a feature branch, e.g. `breakout-unified`. Keep the historical `BreakoutGame/` unchanged until both environments are verified.

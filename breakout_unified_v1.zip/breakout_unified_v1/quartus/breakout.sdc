# No fabric-derived clocks: ALL registers use sys_clk; pixel_div is a clock ENABLE.
create_clock -name sys_clk -period 20.000 [get_ports {sys_clk}]
derive_clock_uncertainty
# Board-dependent external IO delays should be added when real HW is validated.

// Ubuntu: Verilator + FreeGLUT + OpenGL, no FPGA required.
// All simulation and OpenGL happen on ONE thread (no GUI data race).
#include <verilated.h>
#include <GL/glut.h>
#include <array>
#include <cctype>
#include <cstdint>
#include <cstdlib>
#include <cmath>
#include <iostream>
#include <string>
#include "VDevelopmentBoard.h"

constexpr int WIDTH = 640;
constexpr int HEIGHT = 480;
constexpr int CLOCKS_PER_IDLE = 16000;
static VDevelopmentBoard dut;
static std::array<unsigned char, WIDTH * HEIGHT * 3> pixels{};
static bool held[5] = {false,false,false,false,false};
static GLuint texture_id = 0;
static uint64_t frame_count = 0;
static bool frame_ready = false;

// Call after each POSITIVE 50MHz clock edge.
static void step_clock() {
    dut.clk = 0;
    dut.reset = held[0] ? 0 : 1;
    dut.B2 = held[1] ? 0 : 1;
    dut.B3 = held[2] ? 0 : 1;
    dut.B4 = held[3] ? 0 : 1;
    dut.B5 = held[4] ? 0 : 1;
    dut.eval();
    dut.clk = 1;
    dut.eval();

    // pixel_strobe marks updated VGA raster coordinates after each pair of clocks.
    if (dut.pixel_strobe && dut.video_de) {
        const unsigned x = dut.video_x;
        const unsigned y = dut.video_y;
        if (x < WIDTH && y < HEIGHT) {
            const unsigned rgb565 = dut.rgb;
            const size_t n = (static_cast<size_t>(y) * WIDTH + x) * 3;
            pixels[n+0] = static_cast<unsigned char>(((rgb565 >> 11) & 31) * 255 / 31);
            pixels[n+1] = static_cast<unsigned char>(((rgb565 >> 5) & 63) * 255 / 63);
            pixels[n+2] = static_cast<unsigned char>((rgb565 & 31) * 255 / 31);
            if (x == WIDTH-1 && y == HEIGHT-1) {
                ++frame_count;
                frame_ready = true;
            }
        }
    }
    dut.clk = 0;
    dut.eval();
}

static void bitmap_label(float x,float y,const std::string &label) {
    glRasterPos2f(x,y);
    for(unsigned char c:label) glutBitmapCharacter(GLUT_BITMAP_8_BY_13,c);
}
static void led_dot(float cx,float cy,bool active) {
    if (active) glColor3f(1.0f,0.16f,0.10f);
    else glColor3f(0.21f,0.055f,0.045f);
    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(cx,cy);
    for(int i=0;i<=24;++i) {
        const float a=6.2831853f*i/24.0f;
        glVertex2f(cx+11*std::cos(a),cy+11*std::sin(a));
    }
    glEnd();
}
static void display() {
    glClear(GL_COLOR_BUFFER_BIT);
    glBindTexture(GL_TEXTURE_2D,texture_id);
    glTexSubImage2D(GL_TEXTURE_2D,0,0,0,WIDTH,HEIGHT,GL_RGB,GL_UNSIGNED_BYTE,pixels.data());
    glEnable(GL_TEXTURE_2D);
    glColor3f(1,1,1);
    glBegin(GL_QUADS);
        glTexCoord2f(0,1); glVertex2f(80,120);
        glTexCoord2f(1,1); glVertex2f(720,120);
        glTexCoord2f(1,0); glVertex2f(720,600);
        glTexCoord2f(0,0); glVertex2f(80,600);
    glEnd();
    glDisable(GL_TEXTURE_2D);
    glColor3f(1,1,1);
    bitmap_label(130,98,"A RESET  |  S START / LEFT  |  D RIGHT  |  F FIRE RIGHT  |  G FIRE LEFT");
    const char *names[5]={"RESET","LEFT","RIGHT","FIRE-R","FIRE-L"};
    const bool values[5]={bool(dut.led1),bool(dut.led2),bool(dut.led3),bool(dut.led4),bool(dut.led5)};
    for(int i=0;i<5;++i){
        float cx=136.0f+i*130.0f;
        led_dot(cx,58,values[i]);
        glColor3f(1,1,1);
        bitmap_label(cx-24,31,names[i]);
    }
    glutSwapBuffers();
}
static void reshape(int w,int h) {
    // Virtual development board keeps original 800x600 4:3 window layout.
    int vpw=w, vph=h;
    if (static_cast<int64_t>(w)*600 > static_cast<int64_t>(h)*800)
        vpw=h*800/600;
    else vph=w*600/800;
    glViewport((w-vpw)/2,(h-vph)/2,vpw,vph);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0,800,0,600,-1,1);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

static void on_key(unsigned char raw,int,int) {
    const char k=static_cast<char>(std::tolower(raw));
    if (k==27) std::exit(0);
    if(k=='a') held[0]=true;
    if(k=='s') held[1]=true;
    if(k=='d') held[2]=true;
    if(k=='f') held[3]=true;
    if(k=='g') held[4]=true;
}
static void on_release(unsigned char raw,int,int) {
    const char k=static_cast<char>(std::tolower(raw));
    if(k=='a') held[0]=false;
    if(k=='s') held[1]=false;
    if(k=='d') held[2]=false;
    if(k=='f') held[3]=false;
    if(k=='g') held[4]=false;
}
static void idle() {
    for (int i=0;i<CLOCKS_PER_IDLE;++i) step_clock();
    if (frame_ready) {
        frame_ready=false;
        glutPostRedisplay();
    }
}
int main(int argc,char **argv) {
    Verilated::commandArgs(argc,argv);
    dut.clk=0;
    dut.reset=0;dut.B2=1;dut.B3=1;dut.B4=1;dut.B5=1;
    dut.eval();
    // Ensure asynchronous reset is asserted before starting the VGA raster.
    dut.clk=1;dut.eval();dut.clk=0;dut.eval();
    held[0]=false;
    std::cout << "Breakout unified v1 | A=reset S=start/left D=right F=fire right G=fire left ESC=quit\n";
    std::cout << "Simulator uses the SAME RTL as the FPGA, with shortened keyboard debounce.\n";
    glutInit(&argc,argv);
    glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE);
    glutInitWindowSize(800,600);
    glutCreateWindow("FPGA Breakout | VGA 640x480 | A S D F G");
    glClearColor(0,0,0,1);
    glGenTextures(1,&texture_id);
    glBindTexture(GL_TEXTURE_2D,texture_id);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE);
    glPixelStorei(GL_UNPACK_ALIGNMENT,1);
    glTexImage2D(GL_TEXTURE_2D,0,GL_RGB,WIDTH,HEIGHT,0,GL_RGB,GL_UNSIGNED_BYTE,pixels.data());
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutKeyboardFunc(on_key);
    glutKeyboardUpFunc(on_release);
    glutIgnoreKeyRepeat(1);
    glutIdleFunc(idle);
    glutMainLoop();
    dut.final();
    return 0;
}

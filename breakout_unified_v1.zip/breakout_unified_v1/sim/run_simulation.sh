#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
RTL=../rtl
verilator --version
verilator --cc --exe --build -j 0 -O2 -Wall -Wno-fatal \
  --top-module DevelopmentBoard \
  -CFLAGS '-std=c++17 -O2' \
  -LDFLAGS '-lglut -lGLU -lGL' \
  "$RTL/vga_timing.v" "$RTL/key_debounce.v" \
  "$RTL/game_logic.v" "$RTL/pixel_renderer.v" \
  "$RTL/breakout_core.v" DevelopmentBoard.v simulator.cpp
./obj_dir/VDevelopmentBoard

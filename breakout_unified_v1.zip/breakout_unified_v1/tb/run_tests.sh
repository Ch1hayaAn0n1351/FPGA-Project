#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if command -v iverilog >/dev/null 2>&1; then
  for test in tb_game_logic tb_vga_timing; do
    iverilog -g2012 -s "$test" -o "/tmp/${test}.vvp" \
      ../rtl/game_logic.v ../rtl/vga_timing.v "${test}.v"
    vvp "/tmp/${test}.vvp"
  done
elif command -v verilator >/dev/null 2>&1; then
  for test in tb_game_logic tb_vga_timing; do
    verilator --binary --timing -Wall -Wno-fatal --top-module "$test" \
      --Mdir "obj_${test}" ../rtl/game_logic.v ../rtl/vga_timing.v "${test}.v"
    "./obj_${test}/V${test}"
  done
else
  echo 'No HDL simulator found. Install iverilog or verilator.' >&2
  exit 1
fi

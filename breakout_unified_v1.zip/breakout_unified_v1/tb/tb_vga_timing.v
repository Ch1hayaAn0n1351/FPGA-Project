`timescale 1ns / 1ps
module tb_vga_timing;
    reg clk=0, rst_n=0;
    wire pixel_div,hsync,vsync,de,frame_tick;
    wire [9:0] hc,vc,x,y;
    integer n,pixels,active;
    always #10 clk=~clk;
    vga_timing dut(.clk(clk),.rst_n(rst_n),.pixel_div(pixel_div),
      .h_count(hc),.v_count(vc),.hsync(hsync),.vsync(vsync),
      .de(de),.pixel_x(x),.pixel_y(y),.frame_tick(frame_tick));
    initial begin
        @(negedge clk);rst_n=1;
        pixels=0;active=0;
        for(n=0;n<800*525*2;n=n+1) begin
            @(posedge clk);#1;
            if(!pixel_div) begin
                pixels=pixels+1;
                if (de) begin
                    active=active+1;
                    if(x>639 || y>479) begin
                       $display("FAIL: active coord out of range");$finish(1);
                    end
                end
                if ((hc<96) == hsync || (vc<2) == vsync) begin
                    $display("FAIL: hsync/vsync polarity");$finish(1);
                end
            end
        end
        if (pixels!=800*525 || active!=640*480) begin
            $display("FAIL VGA pixels=%0d active=%0d",pixels,active);
            $finish(1);
        end
        $display("ALL VGA TIMING TESTS PASSED pixels=%0d active=%0d",pixels,active);
        $finish;
    end
endmodule

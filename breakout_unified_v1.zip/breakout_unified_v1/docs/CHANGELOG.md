# Repair notes

## v0.1 — initial dual-target reconstruction

Origin: Group 15 BreakoutGame as of 2025-12-31, repository commit `e4628adeaa9f`. This is a clean rewrite of the core with the same gameplay goals, not an edit to the historic files.

- Replaced 794×528 experimental scan and unreset timing counters with 800×525 640×480 @ 25 MHz pixel-enable generator.
- Replaced `0+R5+G5+B5` color packing with actual R5+G6+B5 RGB565 output.
- Changed asynchronous reset into a top-priority reset for all critical game state registers.
- All brick/ball/paddle writes now occur in one sequential owner in `game_logic.v`.
- Changed raster-derived brick collision to predicted next-position rectangle overlap.
- Removed accidental brick 0 revival; victory is now evaluated when last brick is hit.
- Fixed launch directions: hardware KEY3 or simulator F -> up-right, KEY4 or G -> up-left.
- Debounced all four keys and accumulated their one-cycle pulses until the next frame boundary.
- Introduced separate simulator and physical adapters around one identical `breakout_core` module.
- Added VGA/LED GUI and self-contained testbench with scripts.

Outstanding: run HDL tests, inspect GUI, synthesize in Quartus, check all timing, test physically.

#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if command -v iverilog >/dev/null 2>&1; then
  for test in tb_game_logic tb_vga_timing tb_key_debounce tb_pixel_renderer; do
    iverilog -g2012 -s "$test" -o "/tmp/${test}.vvp" \
      ../rtl/game_logic.v ../rtl/vga_timing.v ../rtl/key_debounce.v ../rtl/pixel_renderer.v "${test}.v"
    vvp "/tmp/${test}.vvp"
  done
elif command -v verilator >/dev/null 2>&1; then
  for test in tb_game_logic tb_vga_timing tb_key_debounce tb_pixel_renderer; do
    verilator --binary --timing -Wall --top-module "$test" \
      --Mdir "obj_${test}" ../rtl/game_logic.v ../rtl/vga_timing.v ../rtl/key_debounce.v ../rtl/pixel_renderer.v "${test}.v"
    "./obj_${test}/V${test}"
  done
else
  echo 'No HDL simulator found. Install iverilog or verilator.' >&2
  exit 1
fi

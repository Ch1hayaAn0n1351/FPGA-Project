`timescale 1ns / 1ps
module tb_key_debounce;
    reg clk = 1'b0, rst_n = 1'b0, key_n = 1'b1;
    wire down, pressed;
    integer events = 0;
    always #10 clk <= ~clk;
    key_debounce #(.STABLE_CYCLES(4)) dut (
        .clk(clk), .rst_n(rst_n), .key_n(key_n),
        .down(down), .pressed(pressed)
    );
    always @(posedge clk) begin
        // pressed is already held low by the DUT while rst_n is asserted.
        // Avoid sampling rst_n synchronously in this testbench monitor:
        // the DUT correctly uses it as an asynchronous reset.
        if (pressed) events <= events + 1;
    end
    initial begin
        repeat (3) @(negedge clk);
        rst_n = 1'b1;
        key_n = 1'b0;
        repeat (3) @(negedge clk);
        if (down) begin
            $display("FAIL: key debounce switched too soon");
            $fatal(1);
        end
        repeat (7) @(negedge clk);
        if (!down || events != 1) begin
            $display("FAIL: press event not generated once down=%0b events=%0d", down, events);
            $fatal(1);
        end
        repeat (9) @(negedge clk);
        if (events != 1) begin
            $display("FAIL: repeated press on held key");
            $fatal(1);
        end
        key_n = 1'b1;
        repeat (9) @(negedge clk);
        if (down) begin
            $display("FAIL: key did not release");
            $fatal(1);
        end
        key_n = 1'b0;
        repeat (9) @(negedge clk);
        if (!down || events != 2) begin
            $display("FAIL: second distinct press event");
            $fatal(1);
        end
        $display("ALL KEY DEBOUNCE TESTS PASSED");
        $finish;
    end
endmodule
